package org.Klip29mat1.heap;

import org.bukkit.Bukkit;

public class HeapCleanerPlugin extends org.bukkit.plugin.java.JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("Plugin HeapCleaner activé !");
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            long usedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long maxMemory = Runtime.getRuntime().maxMemory();
            double usedPercentage = ((double) usedMemory / maxMemory) * 100;

            if (usedPercentage >= 90.0) {
                getLogger().warning("La mémoire utilisée est à " + usedPercentage + "%. Nettoyage en cours...");
                System.gc();
                getLogger().info("Nettoyage terminé.");
            }
        }, 0, 6000);
    }

    @Override
    public void onDisable() {
        getLogger().info("Plugin HeapCleaner désactivé !");
    }
}
